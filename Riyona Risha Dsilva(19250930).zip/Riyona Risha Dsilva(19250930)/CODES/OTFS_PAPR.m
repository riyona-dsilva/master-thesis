clc
clear all
%close all
%%
% number of symbol
N = 8;
% number of subcarriers
M = 256;
% size of constellation
M_mod = 16;
M_bits = log2(M_mod);
% number of symbols per frame
N_syms_perfram = N*M;
% number of bits per frame
N_bits_perfram = N*M*M_bits;
numRuns = 1e4; % Number of runs.
papr = zeros(1,numRuns); % Initialize the PAPR results.
Z = 256;
alpha_ = N/2;
N_ = N;
M_ = M;
  alpha = M/2;
%  Ts = M;
%  span_ = N;
for n = 1:numRuns,
            
        %random input bits generation
        data_info_bit = randi([0,1],N_bits_perfram,1);
        data_temp = bi2de(reshape(data_info_bit,N_syms_perfram,M_bits));
        x = qammod(data_temp,M_mod,0,'gray');
        
        x = reshape(x,M,N);
        
        % OTFS modulation
        X = ifft(fft(x).').'/sqrt(M/N); %%%ISFFT
        
%Wtx_c = diag(rcos(M_,alpha));
%Wtx_r = diag(rcos_(N_,alpha_));
%Wtx_c = diag(rcos(M_,alpha));
%Wtx_c = diag(gaus(Ts,span_));
     %  Wtx_r = diag(hanning(N));
      % Wtx_c = diag(hanning(M));
      %  Wtx_c = diag(hamming(M));
 %Wtx_r = diag(hamming(N));
      Wtx_c = diag(ones(M,1));
        Wtx_r = diag(ones(N,1));
 %Wtx_r = diag(rcos_(N_,alpha_));
 %Wtx_r = diag(rcos_(N_,alpha_));

        Win_1 = Wtx_c*X;
        Win_out = Win_1*Wtx_r;
        
        s_mat = ifft(Win_out)*sqrt(M/N); % Heisenberg transform
        
        papr(n) = 10*log10(max(abs(s_mat).^2) / mean(abs(s_mat).^2));
        end 

% Plot CCDF.
[Nl,Xl] = hist(papr, 100);
semilogy(Xl,1-cumsum(Nl)/max(cumsum(Nl)),'m'), grid on;



%%
% s = s_mat(:);
% %channel generation
% taps = 4;
% delay_taps = [0 1 2 3];
% Doppler_taps = [0 1 2 3];
% pow_prof = (1/taps) * (ones(1,taps));
% chan_coef = sqrt(pow_prof).*(sqrt(1/2) * (randn(1,taps)+1i*randn(1,taps)));
