% This function generates a Raised-Cosine pulse h = rcos(M,alpha)
% M is the length of raised cosine pulse
% alpha is the length of roll-off (roll-off factor = 0.5*(M/(M-2*alpha) -
% 1);

function Wtx_c = rcos(M_,alpha)
n1 = 0:alpha-1;
a1 = 0.5.*(1-cos((pi*n1)./(alpha-1)));
a2 = ones(1,M_-2*alpha);
a3 = a1(end:-1:1);
Wtx_c = [a1,a2,a3].';