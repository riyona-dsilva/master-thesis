% This function generates a Raised-Cosine pulse h = rcos(M,alpha)
% M is the length of raised cosine pulse
% alpha is the length of roll-off (roll-off factor = 0.5*(M/(M-2*alpha) -
% 1);

function Wtx_r = rcos_(N_,alpha_)
n1 = 0:alpha_-1;
a1 = 0.5.*(1-cos((pi*n1)./(alpha_-1)));
a2 = ones(1,N_-2*alpha_);
a3 = a1(end:-1:1);
Wtx_r = [a1,a2,a3].';