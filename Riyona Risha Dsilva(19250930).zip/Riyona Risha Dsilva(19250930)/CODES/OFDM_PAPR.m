clc;
clear all;
%close all;

N = 256; %128 Number of subcarriers
% F_N = (1/sqrt(N))*exp(-1i*2*(pi/N)*(0:N-1)'*(0:N-1));%DFT
% F_inv_N = F_N';%IDFT
bps = 4;%bits per symbol
N_sym = 8;
Q = 1; % Bandwidth spreading factor of IFDMA.
numRuns = 1e4; % Number of runs.
papr = zeros(1,numRuns); % Initialize the PAPR results.
for n = 1:numRuns,
info = randsrc(N,N_sym,0:2^bps-1);%information signal, of size Nx1
%; stem(info); grid on;
c = sqrt(10); d = qammod(info,2^bps)/c;%16-QAM modulation
%figure; scatterplot(d);
% x = F_inv_N*d; %OFDM signal
x  = sqrt(N)*ifft(d,N);
papr(n) = 10*log10(max(abs(x).^2) / mean(abs(x).^2));
end
% Plot CCDF.
[Nl,Xl] = hist(papr, 100);
semilogy(Xl,1-cumsum(Nl)/max(cumsum(Nl)),'k'), grid on , xlabel('PAPR(dB)'), ylabel('Pr(PAPR>PAPR0)'), title('Comparison of PAPR analysis between different modulation techniques');
Ncp = N/4;%Number of samples in the cyclic prefix
I_N = eye(N);%identity matrix
Acp = [I_N(end-Ncp+1:end,:);I_N];%Appending cyclic prefix to the identity matrix
s_t = Acp*x; %cyclic prefix multiplied to the vector x 
s_t_temp = [x(end-Ncp+1:end,:);x];
s_t_serial = s_t_temp(:);%This should give the same result as s_t
%max(abs(s_t-s_t_temp));%should be equal to zero because both the vectors are the same

%Receiver
h = randn(10,1)+1i*randn(10,1);
s_r = conv(s_t_serial,h);
s_r_parallel=reshape(s_r(1:end-9),N+Ncp,N_sym);
z_r_R = [(zeros(N,Ncp)),I_N];
s_r_Nocp = z_r_R*s_r_parallel;
h_f = fft(h,N);
%y2 = s_t_parallel(Ncp+1:end,:);
%max(abs(s_r-y2));
y3 = (1/sqrt(N))*fft(s_r_Nocp,N);
y0  = sqrt(N)*ifft(y3,N);
%rr = sqrt(4);
y4 = qamdemod(y0*c,2^bps);
var(y4);
%figure; stem(y4); grid on; axis([0 140 0 15]);








